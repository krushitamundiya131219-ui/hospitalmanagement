package com.hospital.dao;

import com.hospital.model.Patient;
import com.hospital.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class PatientDao {

    public void save(Patient patient) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(patient);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

   public List<Patient> getAllPatients() {
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        return session.createQuery("from Patient", Patient.class).list();
    }
}


    // ✅ Add this method
    public Patient findById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Patient.class, id);
        }
    }
}
