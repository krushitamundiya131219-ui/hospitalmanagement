package com.hospital.servlet;

import com.hospital.dao.AppointmentDao;
import com.hospital.dao.DoctorDao;
import com.hospital.dao.PatientDao;
import com.hospital.model.Appointment;
import com.hospital.model.Doctor;
import com.hospital.model.Patient;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/appointments")
public class AppointmentServlet extends HttpServlet {
    private final AppointmentDao appointmentDao = new AppointmentDao();
    private final PatientDao patientDao = new PatientDao();
    private final DoctorDao doctorDao = new DoctorDao();

    @Override
    protected void doPost(HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp) throws ServletException, IOException {
        Integer patientId = Integer.valueOf(req.getParameter("patientId"));
        Integer doctorId = Integer.valueOf(req.getParameter("doctorId"));
        LocalDate date = LocalDate.parse(req.getParameter("appointmentDate"));
        String notes = req.getParameter("notes");

        Patient p = patientDao.findById(patientId);
        Doctor d = doctorDao.findById(doctorId);

        Appointment a = new Appointment();
        a.setPatient(p);
        a.setDoctor(d);
        a.setAppointmentDate(date);
        a.setNotes(notes);

        appointmentDao.save(a);
        resp.sendRedirect(req.getContextPath() + "/success.jsp");
    }
}
