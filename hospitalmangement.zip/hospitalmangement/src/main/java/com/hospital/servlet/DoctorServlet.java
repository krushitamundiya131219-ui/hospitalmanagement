package com.hospital.servlet;

import com.hospital.dao.DoctorDao;
import com.hospital.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/doctors")
public class DoctorServlet extends HttpServlet {

    private final DoctorDao dao = new DoctorDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Doctor> doctors = dao.getAllDoctors();
        request.setAttribute("doctors", doctors);
        request.getRequestDispatcher("viewDoctor.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String specialization = request.getParameter("specialization");
        String email = request.getParameter("email");
        String specialty = request.getParameter("specialty");

        Doctor doctor = new Doctor(name, specialization, email, specialty);
        dao.save(doctor);
        System.out.println("✅ Doctor saved successfully: " + name);

        request.getRequestDispatcher("success.jsp").forward(request, response);
    }
}
