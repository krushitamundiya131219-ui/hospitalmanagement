package com.hospital.servlet;

import com.hospital.dao.PatientDao;
import com.hospital.model.Patient;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/patients")
public class PatientServlet extends HttpServlet {

    private final PatientDao dao = new PatientDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Patient> patients = dao.getAllPatients();

        // ✅ Debug log (check your Tomcat console)
        System.out.println("Patients fetched from DB: " + patients.size());

        request.setAttribute("patients", patients);
        request.getRequestDispatcher("viewPatient.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");
        String address = request.getParameter("address");

        Patient patient = new Patient(name, email, phone, address, gender);
        dao.save(patient);

        System.out.println("✅ Patient saved successfully: " + name);

        request.getRequestDispatcher("success.jsp").forward(request, response);
    }
}
